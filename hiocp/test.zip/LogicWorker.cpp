#include "pch.h"
#include "LogicWorker.hpp"
#include "CustomStructs.hpp"

LogicWorker::LogicWorker()
{
}

LogicWorker::~LogicWorker()
{
	for (int i = 0; i < 4; ++i) {
		Workers[i].join();
	}
}

void LogicWorker::Run() {
	for (int i = 0; i < 4; ++i)
	{
		Workers.push_back(std::thread([&]() {
			while (true) {
				std::unique_lock<std::mutex> lock(qMutex);
				cv.wait(lock, [&] {return !TaskQueue.empty(); });

				std::cout << "������Ŀ����" << std::endl;
				Task task = std::move(TaskQueue.front());
				TaskQueue.pop();
				lock.unlock();

				auto ctx = task.session->GetCtx();

				ZeroMemory(&ctx->buffer, sizeof(ctx->buffer));
				std::string msg = task.rawData;
				strcpy_s(ctx->buffer, msg.c_str());
				ctx->wsabuf.len = static_cast<ULONG>(msg.size());

				ctx->oper = OPER::SEND;
				ZeroMemory(&ctx->overlapped, sizeof(ctx->overlapped));

				WSASend(ctx->clientSock, &ctx->wsabuf, 1, nullptr, 0, &ctx->overlapped, nullptr);
			}
			}));
	}
}

void LogicWorker::PustTask(Task&& t)
{
	TaskQueue.push(std::move(t));
}
