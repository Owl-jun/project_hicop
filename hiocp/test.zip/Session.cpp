#include "pch.h"
#include "Session.hpp"
#include "SessionManager.hpp"



Session::Session(std::shared_ptr<IOContext> _ctx)
{
	ctx = _ctx;
}

Session::~Session()
{
}

void Session::close()
{
	closesocket(ctx->clientSock);
}

void Session::SetPk(int _pk)
{
	pk = _pk;
}

SOCKET Session::GetSocket()
{
	return ctx->clientSock;
}

int Session::GetPK()
{
	return pk;
}

